<?php
require 'layout.php';
?>  
  <div class="container-fluid"  style="max-width: 50%;margin: 3%">
           
<?php
require 'config.php';
if(isset($_GET['Name'])){
$query = "select problem_def from practice_problem where problem_id =\"".$_GET['Name']."\"";
if($result = mysqli_query($dbConn,$query))
{
    $row = mysqli_fetch_array($result);
    $myfile = fopen($row[0], "r") or die("Unable to open file!");
while(!feof($myfile)) {
  echo "<b>".fgets($myfile) . "<br>"."</b>";
}
fclose($myfile);
 ?> 
          
  <a id="buttondesign" style="right:  5%;bottom: 5%" data-spy="affix" href="terminal123.php?Code_id=<?php printf($_GET['Name']) ?>">Submit Code</a>
        
        <?php
}

else
{
    printf("<h3>Sorry No Problem found...... Please check the problem name!!!!</h3>");
}

}
else
{
    header("Location: ./index.php");
}

?>
</div>
</body>
</html>
