<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="bootstrap.min.css">
<link rel=stylesheet href="code/doc/docs.css">
<link rel="stylesheet" href="bootstrap-datetimepicker.min.css">
        <link rel="stylesheet" href="portal_design.css">
        <script src="jquery.min.js"></script>
        <script src="bootstrap.min.js"></script>
        <title>Code here ;)</title>
        <link rel='icon' href='IIITGLogo2.png'>

</head>
<body>
<ul class="nav nav-tabs" >
  <li class="active"><a href="portal_index.php">Home</a></li>
  <li><a href="mainpage.php">Problems</a></li>
  
  <li><a href="contest.php">Contest</a></li>
 
  <li><a href="submission.php">ViewSubmissions</a></li>
<li><a href="event_ranking.php?Name=EVNT001_Ranking">Ranking</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
