<?php
require 'config.php';
$roll=$_POST['Roll_number'];
$default="abc";
$type=1;
$query="insert into user_login(`username`,`password`,`type`) values('$roll','$default','$type')";
mysqli_query($dbConn, $query) or die(mysqli_error($dbConn));
require 'admin_index.php';
?>
