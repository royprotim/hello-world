<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="bootstrap.min.css">
<link rel=stylesheet href="code/doc/docs.css">
<link rel="stylesheet" href="bootstrap-datetimepicker.min.css">
        <link rel="stylesheet" href="portal_design.css">
        <script src="jquery.min.js"></script>
        <script src="bootstrap.min.js"></script>
        <title>Code here ;)</title>
        <link rel='icon' href='IIITGLogo2.png'>

</head>
<body>

<ul class="nav nav-tabs" >
  <li class="active"><a href="admin_index.php">Home</a></li>
  <li><a href="registration.php">Add_Student</a></li>
  
  <li><a href="add_problem.php">Add_Problem</a></li>
<li><a href="addevent.php">Add_Event</a></li>
  <li><a href="event.php">Event</a></li>
  <li><a href="questions.php">View_Problems</a></li>
  <li><a href="admin_submission.php?NAME=default">Submissions</a></li>
 <li><a href="event_submission.php?Name=EVNT001/default">Event_Submissions</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>

