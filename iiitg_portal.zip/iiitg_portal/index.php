<html>
<body>
<div class="form" style="max-width: 50%;margin: 10%">
	<i><b>Login</b></i>
	</br></br>
            <form action="info.php" method="post" enctype="multipart/form-data">
                    
                      
                   <input type="text"  name="std_roll" id="username" placeholder="UserRoll" >
                    </br> </br>
                    
                   <input type="text"  name="std_pass" id="username" placeholder="Password" >
                    </br></br> 
                    
	
                           <input type="submit" name="Submit">
                        <input type="reset" name="Reset">
                   </br>

        </form>
        </div>
  </body>
</html>

