<?php
require 'admin_layout.php';
?>
        <div class="form" style="max-width: 50%;margin: 5%">
            <form action="do_register.php" method="post" enctype="multipart/form-data">
                    
                     
                   	<b><i>	<input type="text"  name="Roll_number" id="Roll_number"  placeholder="Roll_Number" ></i></b>

                    	</br>
</br>

                    
                           <input type="submit" name="Register">
                        <input type="reset" name="Reset">
                   </br>

        </form>
        </div>
    </body>
</html>
